<?php include("conn.php"); ?>

<?php 


?>

<html>
<head>
</head>
<body>
<h1>Welcome Admin Home </h1>
<div>
	<a href="addnewproduct.php">Add New Product </a> <br>
	
	<a href="viewproducts.php">View Products </a> <br>
<div>
</body>

</html>























